DMD — Davenport Mobile Detailing website

index.html is the complete responsive website.

Before launch:
1. Add DMD's real phone number and business email.
2. Replace the booking form mailto destination with the real business email.
3. Add real before/after photos.
4. Publish index.html with a web host and connect your domain.
